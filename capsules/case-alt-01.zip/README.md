# ChangeProof Reproduction Capsule — case-alt-01

Base Commit: `main`
Spec SHA256: `ec0ca9451dab1a96a9bd451e9667a78a6843e14d6b60d17f0c3d4fc92baa1f32`

## Clean Replay Instructions
```bash
python changeproof/replay.py capsules/case-alt-01.zip
```
