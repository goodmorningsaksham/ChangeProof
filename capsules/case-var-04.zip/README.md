# ChangeProof Reproduction Capsule — case-var-04

Base Commit: `git-case-var-04`
Spec SHA256: `11ab8d2c684c149a915a968cc1380bcad50410eab5f8ed1a809665833e08545a`

## Clean Replay Instructions
```bash
python changeproof/replay.py capsules/case-var-04.zip
```
