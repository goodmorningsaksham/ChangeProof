# ChangeProof Reproduction Capsule — case-var-03

Base Commit: `git-case-var-03`
Spec SHA256: `9a9560d5f5f30dc90374705d4e41578baa34ab8cf9721f5021b583c9fda75be5`

## Clean Replay Instructions
```bash
python changeproof/replay.py capsules/case-var-03.zip
```
