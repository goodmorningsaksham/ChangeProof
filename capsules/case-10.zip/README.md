# ChangeProof Reproduction Capsule — case-10

Base Commit: `main`
Spec SHA256: `8213f958f0f9daabe3ca665ee59ddf270ac4c990318bb40306378f4056295cb5`

## Clean Replay Instructions
```bash
python changeproof/replay.py capsules/case-10.zip
```
