# ChangeProof Reproduction Capsule — case-01_live

Base Commit: `e58c85d`
Spec SHA256: `3e2c68df08317168c4a080181924ae3b2a7c723988ef384ca25951e31b644d89`

## Clean Replay Instructions
```bash
python changeproof/replay.py capsules/case-01_live.zip
```
