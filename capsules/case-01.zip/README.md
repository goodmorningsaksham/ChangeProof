# ChangeProof Reproduction Capsule — case-01

Base Commit: `main`
Spec SHA256: `e2a834dae5e1efb024d7fe13c73dfc9ba5998815d62d51939d34b49258c95186`

## Clean Replay Instructions
```bash
python changeproof/replay.py capsules/case-01.zip
```
