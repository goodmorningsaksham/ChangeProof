# ChangeProof Reproduction Capsule — case-var-05

Base Commit: `git-case-var-05`
Spec SHA256: `b3bb08816cebd4bbebc1395c045dff8b1d4ed3fc57e2f90cf915f03975f5b5f1`

## Clean Replay Instructions
```bash
python changeproof/replay.py capsules/case-var-05.zip
```
