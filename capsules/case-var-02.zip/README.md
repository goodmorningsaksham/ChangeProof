# ChangeProof Reproduction Capsule — case-var-02

Base Commit: `git-case-var-02`
Spec SHA256: `95f40192f330156d0d74d82678bb8a83beee3e5dd1f49da89a2613b52beac740`

## Clean Replay Instructions
```bash
python changeproof/replay.py capsules/case-var-02.zip
```
