# CHANGE PROOF CERTIFICATE
Generated: 2026-08-30T09:38:13Z | Experiment: case-framework-gen-01 | Commit: main


> **STATUS**: [PASS] PROVEN & VERIFIED SAFE — Patch passed deterministic criteria.


## Evaluation Summary
- **Risk Level**: HIGH (Score: 105/100)
- **Failure Class**: Retry Amplification / Retry Storm
- **Primary Hypothesis**: Downstream latency induces retry amplification storm due to elevated retry ceiling (Confidence: HIGH)
- **Deterministic Verification Verdict**: **PASS**


## Candidate Hypotheses Evaluated (Multi-Signal Analysis)

> **Note on Joint Attribution**: 3 signals were changed together in this diff and evaluated via a single combined experiment. This confirms the **COMBINATION** produced the observed failure; it does not isolate which individual signal(s) would be sufficient on their own. Independent attribution would require separate ablation experiments per signal.


| Hypothesis ID | Signal / Trigger | Mechanism & Grounding | Experiment Verdict | Telemetry Evidence |
|---|---|---|---|---|

| **H-RETRY-CEILING** | Aggressive retry count increase (max_retries >= 4) | Elevated retry ceiling (RETRIES_MAX >= 4) allows each stalled request to execute multiple consecutive retries. | `[CONSISTENT WITH OBSERVED STORM]` | Observed pre-patch 7.000 retries/req (>2.0 condition met across 150 requests) directly confirms elevated retry ceiling amplifies failed calls. |

| **H-NO-BACKOFF** | Removal of backoff / immediate retry execution | Removal of exponential backoff delay (RETRY_BACKOFF_FACTOR = 0.0) concentrates retries in rapid bursts. | `[CONSISTENT WITH OBSERVED STORM]` | Observed storm rate of 1037.38 retries/min confirms zero-backoff allows all retries to fire rapidly in tight succession without spacing. |

| **H-AGGRESSIVE-TIMEOUT** | Aggressive timeout reduction (timeout < 1.0s) | Lowered client timeout (RETRY_TIMEOUT_SECONDS < 1.0s) causes client-side timeout before downstream processing completes. | `[CONSISTENT WITH OBSERVED STORM]` | Downstream latency (1500ms) exceeded client timeout (500ms), causing 100% of requests to timeout prematurely and trigger full retry loops. |



## Key Metric Observations & Throughput Context
| Metric | Pre-Patch (Broken) | Post-Patch (Remediated) | Target / Safe Bound | Status |
|---|---|---|---|---|
| **Retries / Request** | **7.0** | **1.0** | `> 2.0` (Pre) / `<= 1.1` (Post) | CONTROLLED |
| **Throughput (req/s)** | 2.47 req/s | 3.96 req/s | Context (Normalized capacity) | Reported |
| **Total Requests** | 150.0 | 150.0 | `>= 100` Sample Size | Validated |
| **Rate (retries/min)** | 1037.38 /min | 237.47 /min | Context (Un-normalized rate) | Reported |

## Deterministic Assertion Verification
| Metric | Phase | Observed Value | Condition | Condition Met |
|---|---|---|---|---|

| retries_per_request | pre_patch | 7.0 | `> 2.0` | YES |

| total_requests | pre_patch | 150.0 | `>= 100` | YES |

| retries_per_request | post_patch | 1.0 | `<= 1.1` | YES |

| total_requests | post_patch | 150.0 | `>= 100` | YES |



## Recommended Remediation Patch
```diff
--- a/app/flask_service/app.py
+++ b/app/flask_service/app.py
@@ -10,3 +10,3 @@
-RETRIES_MAX = 8
-RETRY_TIMEOUT_SECONDS = 0.5
-RETRY_BACKOFF_FACTOR = 0.0
+RETRIES_MAX = 2
+RETRY_TIMEOUT_SECONDS = 1.0
+RETRY_BACKOFF_FACTOR = 0.5

```


## Reproducibility & Artifacts
- **Reproduction Capsule**: `capsules\case-framework-gen-01.zip`
- **Replay Command**: `python changeproof/replay.py capsules\case-framework-gen-01.zip`

## Human Engineering Decision
[ ] APPROVED FOR DEPLOYMENT   [ ] REJECTED   [ ] ESCALATE FOR REVIEW
Reviewer Signature: _______________________ Date: _______________