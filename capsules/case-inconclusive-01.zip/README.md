# ChangeProof Reproduction Capsule — case-inconclusive-01

Base Commit: `inconclusive-boundary-run`
Spec SHA256: `754fca79ad4387fd1bad233f572fe536b8afd3a28c976d577e3628b5ea2a7a9b`

## Clean Replay Instructions
```bash
python changeproof/replay.py capsules/case-inconclusive-01.zip
```
