# ChangeProof Reproduction Capsule — case01-synth-live-verify

Base Commit: `synth-live-verify`
Spec SHA256: `4d05b76c4defb4e1a525026952c07c61e74b4061a9960a80a94e529266f31cda`

## Clean Replay Instructions
```bash
python changeproof/replay.py capsules/case01-synth-live-verify.zip
```
