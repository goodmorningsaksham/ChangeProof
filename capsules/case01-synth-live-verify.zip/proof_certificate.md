# CHANGE PROOF CERTIFICATE
Generated: 2026-08-29T11:07:42Z | Experiment: case-01-live-ci | Commit: synth-live-verify


> **STATUS**: ✅ **PROVEN & VERIFIED SAFE** — Patch passed deterministic criteria.


## Evaluation Summary
- **Risk Level**: HIGH (Score: 70/100)
- **Failure Class**: Retry Amplification / Retry Storm
- **Hypothesis**: Topology-Synthesized: Downstream Latency Induces Retry Amplification (checkout -> payment) (Confidence: HIGH)
- **Deterministic Verification Verdict**: **PASS**

## Key Metric Observations & Throughput Context
| Metric | Pre-Patch (Broken) | Post-Patch (Remediated) | Target / Safe Bound | Status |
|---|---|---|---|---|
| **Retries / Request** | **7.0** | **1.0** | `> 2.0` (Pre) / `<= 1.1` (Post) | ✅ CONTROLLED |
| **Throughput (req/s)** | 3.64 req/s | 5.84 req/s | Context (Normalized capacity) | ℹ️ Reported |
| **Total Requests** | 150 | 150 | `>= 100` Sample Size | ✅ Validated |
| **Rate (retries/min)** | 1530.12 /min | 350.2 /min | Context (Un-normalized rate) | ℹ️ Reported |

## Deterministic Assertion Verification
| Metric | Phase | Observed Value | Condition | Condition Met |
|---|---|---|---|---|

| retries_per_request | pre_patch | 7.0 | `> 2.0` | YES |

| total_requests | pre_patch | 150.0 | `>= 100` | YES |

| retries_per_request | post_patch | 1.0 | `<= 1.1` | YES |

| total_requests | post_patch | 150.0 | `>= 100` | YES |


## Reproducibility & Artifacts
- **Reproduction Capsule**: `capsules\case-01.zip`
- **Replay Command**: `python changeproof/replay.py capsules\case-01.zip`

## Human Engineering Decision
[ ] APPROVED FOR DEPLOYMENT   [ ] REJECTED   [ ] ESCALATE FOR REVIEW
Reviewer Signature: _______________________ Date: _______________