# ChangeProof Reproduction Capsule — case-calib-02

Base Commit: `calib-timeout-1.3`
Spec SHA256: `90353e11b96d398e0f7c70785c9bb751380ea3597b6972bfa621b115d08f1372`

## Clean Replay Instructions
```bash
python changeproof/replay.py capsules/case-calib-02.zip
```
