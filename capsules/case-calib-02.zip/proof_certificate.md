# CHANGE PROOF CERTIFICATE
Generated: 2026-08-29T12:33:12Z | Experiment: case-calib-02 | Commit: calib-timeout-1.3


> **STATUS**: [PASS] PROVEN & VERIFIED SAFE — Patch passed deterministic criteria.


## Evaluation Summary
- **Risk Level**: HIGH (Score: 60/100)
- **Failure Class**: Retry Amplification / Retry Storm
- **Primary Hypothesis**: Topology-Synthesized: Downstream Latency Induces Retry Amplification (checkout -> payment) (Confidence: HIGH)
- **Deterministic Verification Verdict**: **PASS**


## Candidate Hypotheses Evaluated (Multi-Signal Analysis)

> **Note on Joint Attribution**: 2 signals were changed together in this diff and evaluated via a single combined experiment. This confirms the **COMBINATION** produced the observed failure; it does not isolate which individual signal(s) would be sufficient on their own. Independent attribution would require separate ablation experiments per signal.


| Hypothesis ID | Signal / Trigger | Mechanism & Grounding | Experiment Verdict | Telemetry Evidence |
|---|---|---|---|---|

| **H-RETRY-CEILING** | Aggressive retry count increase (max_retries >= 4) | Elevated retry ceiling (RETRIES_MAX >= 4) allows each stalled request to execute multiple consecutive retries. | `[CONSISTENT WITH OBSERVED STORM]` | Observed pre-patch 4.000 retries/req (>2.0 condition met across 150 requests) directly confirms elevated retry ceiling amplifies failed calls. |

| **H-NO-BACKOFF** | Removal of backoff / immediate retry execution | Removal of exponential backoff delay (RETRY_BACKOFF_FACTOR = 0.0) concentrates retries in rapid bursts. | `[CONSISTENT WITH OBSERVED STORM]` | Observed storm rate of 712.27 retries/min confirms zero-backoff allows all retries to fire rapidly in tight succession without spacing. |



## Key Metric Observations & Throughput Context
| Metric | Pre-Patch (Broken) | Post-Patch (Remediated) | Target / Safe Bound | Status |
|---|---|---|---|---|
| **Retries / Request** | **4.0** | **1.0** | `> 2.0` (Pre) / `<= 1.1` (Post) | CONTROLLED |
| **Throughput (req/s)** | 2.97 req/s | 5.85 req/s | Context (Normalized capacity) | Reported |
| **Total Requests** | 150.0 | 150.0 | `>= 100` Sample Size | Validated |
| **Rate (retries/min)** | 712.27 /min | 350.86 /min | Context (Un-normalized rate) | Reported |

## Deterministic Assertion Verification
| Metric | Phase | Observed Value | Condition | Condition Met |
|---|---|---|---|---|

| retries_per_request | pre_patch | 4.0 | `> 2.0` | YES |

| total_requests | pre_patch | 150.0 | `>= 100` | YES |

| retries_per_request | post_patch | 1.0 | `<= 1.1` | YES |

| total_requests | post_patch | 150.0 | `>= 100` | YES |


## Reproducibility & Artifacts
- **Reproduction Capsule**: `capsules/case-calib-02.zip`
- **Replay Command**: `python changeproof/replay.py capsules/case-calib-02.zip`

## Human Engineering Decision
[ ] APPROVED FOR DEPLOYMENT   [ ] REJECTED   [ ] ESCALATE FOR REVIEW
Reviewer Signature: _______________________ Date: _______________