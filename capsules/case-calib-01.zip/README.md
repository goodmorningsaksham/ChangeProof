# ChangeProof Reproduction Capsule — case-calib-01

Base Commit: `calib-timeout-0.3`
Spec SHA256: `427e871f360bf11a4167eb00880d55e6ffd8bf721365717e0b444c528f4a0f3e`

## Clean Replay Instructions
```bash
python changeproof/replay.py capsules/case-calib-01.zip
```
