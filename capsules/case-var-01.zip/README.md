# ChangeProof Reproduction Capsule — case-var-01

Base Commit: `git-case-var-01`
Spec SHA256: `6ff8deff0fb9abc66cc0aaa1a464735e79de7a407a9d5ec3b3e762d7e16b9a66`

## Clean Replay Instructions
```bash
python changeproof/replay.py capsules/case-var-01.zip
```
