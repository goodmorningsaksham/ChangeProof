# CHANGE PROOF CERTIFICATE
Generated: 2026-08-30T19:53:54Z | Experiment: case-self-correction-01 | Commit: case-self-correction-01-live


> **STATUS**: [PASS] PROVEN & VERIFIED SAFE — Patch passed deterministic criteria.


## Evaluation Summary
- **Risk Level**: CRITICAL (Score: 90/100)
- **Failure Class**: Retry Amplification / Retry Storm
- **Primary Hypothesis**: Retry storm amplification under downstream latency (Confidence: HIGH)
- **Deterministic Verification Verdict**: **PASS**



## Key Metric Observations & Throughput Context
| Metric | Pre-Patch (Broken) | Post-Patch (Remediated) | Target / Safe Bound | Status |
|---|---|---|---|---|
| **Retries / Request** | **7.0** | **0.0** | `> 2.0` (Pre) / `<= 1.1` (Post) | CONTROLLED |
| **Throughput (req/s)** | 3.0 req/s | 6.49 req/s | Context (Normalized capacity) | Reported |
| **Total Requests** | 150 | 150 | `>= 100` Sample Size | Validated |
| **Rate (retries/min)** | 1257.99 /min | 0.0 /min | Context (Un-normalized rate) | Reported |

## Deterministic Assertion Verification
| Metric | Phase | Observed Value | Condition | Condition Met |
|---|---|---|---|---|

| retries_per_request | pre_patch | 7.0 | `>= 2.0` | YES |

| total_requests | pre_patch | 150.0 | `>= 100` | YES |

| retries_per_request | post_patch | 0.0 | `<= 1.1` | YES |

| total_requests | post_patch | 150.0 | `>= 100` | YES |



## Remediation Patch Trajectory (Agentic Feedback Loop)
The initial remediation patch was insufficient and underwent automated self-correction based on empirical verification telemetry.


### Patch Attempt 1 — Verdict: `[FAIL]`
- **Reasoning / Diagnosis** [LLM]: Attempt 1: Modestly reduced RETRIES_MAX from 8 to 3 to lower amplification ceiling.
- **Observed Post-Patch Metrics**: 2.0 retries/req (Rate: 945.22/min, Throughput: 7.88 req/s)
- **Verification Result**: Post-patch experiment violated safety thresholds

```diff
--- a/app/checkout/main.py
+++ b/app/checkout/main.py
@@ -11,7 +11,7 @@
 
 # Configuration (Defaults for baseline behavior)
 PAYMENT_SERVICE_URL = os.getenv("PAYMENT_SERVICE_URL", "http://toxiproxy:18002")
-RETRIES_MAX = int(os.getenv("RETRIES_MAX", "8"))
+RETRIES_MAX = int(os.getenv("RETRIES_MAX", "3"))
 RETRY_TIMEOUT_SECONDS = float(os.getenv("RETRY_TIMEOUT_SECONDS", "0.4"))
 RETRY_BACKOFF_FACTOR = float(os.getenv("RETRY_BACKOFF_FACTOR", "0.0"))
 

```


### Patch Attempt 2 — Verdict: `[PASS]`
- **Reasoning / Diagnosis** [LLM]: Attempt 1 failed because RETRIES_MAX was still too high (3) and RETRY_BACKOFF_FACTOR was left at 0.0, which allowed immediate, back-to-back retries. Furthermore, the aggressive timeout of 0.4s caused premature aborts on slow downstream responses, immediately triggering retries and resulting in an average of 2.0 retries per request, violating the safety threshold of <= 1.1. To strictly enforce the safety threshold of <= 1.1 retries per request, we must reduce RETRIES_MAX to 1. We also increase RETRY_TIMEOUT_SECONDS to 1.5s to prevent premature timeouts, and set RETRY_BACKOFF_FACTOR to 1.0 to introduce a safe delay between attempts, mitigating retry storms.
- **Observed Post-Patch Metrics**: 0.0 retries/req (Rate: 0.0/min, Throughput: 6.49 req/s)
- **Verification Result**: Fix verified successfully

```diff
--- a/app/checkout/main.py
+++ b/app/checkout/main.py
@@ -11,9 +11,9 @@
 
 # Configuration (Defaults for baseline behavior)
 PAYMENT_SERVICE_URL = os.getenv("PAYMENT_SERVICE_URL", "http://toxiproxy:18002")
-RETRIES_MAX = int(os.getenv("RETRIES_MAX", "8"))
-RETRY_TIMEOUT_SECONDS = float(os.getenv("RETRY_TIMEOUT_SECONDS", "0.4"))
-RETRY_BACKOFF_FACTOR = float(os.getenv("RETRY_BACKOFF_FACTOR", "0.0"))
+RETRIES_MAX = int(os.getenv("RETRIES_MAX", "1"))
+RETRY_TIMEOUT_SECONDS = float(os.getenv("RETRY_TIMEOUT_SECONDS", "1.5"))
+RETRY_BACKOFF_FACTOR = float(os.getenv("RETRY_BACKOFF_FACTOR", "1.0"))
 
 # Prometheus Metrics
 CHECKOUT_REQUESTS_TOTAL = Counter(

```




## Reproducibility & Artifacts
- **Reproduction Capsule**: `capsules/case-self-correction-01.zip`
- **Replay Command**: `python -m changeproof.replay capsules/case-self-correction-01.zip`

## Human Engineering Decision
[ ] APPROVED FOR DEPLOYMENT   [ ] REJECTED   [ ] ESCALATE FOR REVIEW
Reviewer Signature: _______________________ Date: _______________