# ChangeProof Reproduction Capsule — case-self-correction-01

Base Commit: `case-self-correction-01-live`
Spec SHA256: `e9d18476d5a13e08610dc7cfebf36c6182164585d237931d0ba54a3993aaf072`

## Clean Replay Instructions
```bash
python changeproof/replay.py capsules/case-self-correction-01.zip
```
