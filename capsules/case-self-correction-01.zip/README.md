# ChangeProof Reproduction Capsule — case-self-correction-01

Base Commit: `case-self-correction-01-live`
Spec SHA256: `bf4602e8c1e8290bbc48f5d55e0144be4b30318fb3d7e14faff4f8a2b935f3e8`

## Clean Replay Instructions
```bash
python changeproof/replay.py capsules/case-self-correction-01.zip
```
