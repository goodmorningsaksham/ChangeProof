# CHANGE PROOF CERTIFICATE
Generated: 2026-08-30T09:17:19Z | Experiment: case-ablation-backoff-01 | Commit: main


> **STATUS**: [PASS] PROVEN & VERIFIED SAFE — Patch passed deterministic criteria.


## Evaluation Summary
- **Risk Level**: MEDIUM (Score: 20/100)
- **Failure Class**: Retry Amplification / Retry Storm
- **Primary Hypothesis**: Immediate unspaced retries concentrate downstream traffic and spike storm rate (Confidence: HIGH)
- **Deterministic Verification Verdict**: **PASS**


## Candidate Hypotheses Evaluated (Multi-Signal Analysis)


| Hypothesis ID | Signal / Trigger | Mechanism & Grounding | Experiment Verdict | Telemetry Evidence |
|---|---|---|---|---|

| **H-NO-BACKOFF** | Removal of backoff / immediate retry execution | Removal of exponential backoff delay (RETRY_BACKOFF_FACTOR = 0.0) concentrates retries in rapid bursts. | `[SUPPORTED (ISOLATED)]` | Observed storm rate of 435.31 retries/min confirms zero-backoff allows all retries to fire rapidly in tight succession without spacing. |



## Key Metric Observations & Throughput Context
| Metric | Pre-Patch (Broken) | Post-Patch (Remediated) | Target / Safe Bound | Status |
|---|---|---|---|---|
| **Retries / Request** | **2.0** | **1.0** | `> 2.0` (Pre) / `<= 1.1` (Post) | CONTROLLED |
| **Throughput (req/s)** | 3.63 req/s | 5.83 req/s | Context (Normalized capacity) | Reported |
| **Total Requests** | 150.0 | 150.0 | `>= 100` Sample Size | Validated |
| **Rate (retries/min)** | 435.31 /min | 349.51 /min | Context (Un-normalized rate) | Reported |

## Deterministic Assertion Verification
| Metric | Phase | Observed Value | Condition | Condition Met |
|---|---|---|---|---|

| retries_per_request | pre_patch | 2.0 | `>= 1.8` | YES |

| total_requests | pre_patch | 150.0 | `>= 100` | YES |

| retries_per_request | post_patch | 1.0 | `<= 1.1` | YES |

| total_requests | post_patch | 150.0 | `>= 100` | YES |



## Recommended Remediation Patch
```diff
--- a/app/checkout/main.py
+++ b/app/checkout/main.py
@@ -10,3 +10,3 @@
-RETRIES_MAX = 3
-RETRY_TIMEOUT_SECONDS = 1.0
-RETRY_BACKOFF_FACTOR = 0.0
+RETRIES_MAX = 2
+RETRY_TIMEOUT_SECONDS = 1.0
+RETRY_BACKOFF_FACTOR = 0.5

```


## Reproducibility & Artifacts
- **Reproduction Capsule**: `capsules\case-ablation-backoff-01.zip`
- **Replay Command**: `python changeproof/replay.py capsules\case-ablation-backoff-01.zip`

## Human Engineering Decision
[ ] APPROVED FOR DEPLOYMENT   [ ] REJECTED   [ ] ESCALATE FOR REVIEW
Reviewer Signature: _______________________ Date: _______________