"""Target application package."""
