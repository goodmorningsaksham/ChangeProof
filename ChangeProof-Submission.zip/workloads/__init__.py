"""Package init for workloads."""
