"""Package init for evaluation."""
